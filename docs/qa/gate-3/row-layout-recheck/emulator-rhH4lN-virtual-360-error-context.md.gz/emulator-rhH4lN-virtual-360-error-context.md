# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: g3-row-layout.spec.ts >> G3 virtual Project rows fit long and short titles at 360px
- Location: tests\e2e\g3-row-layout.spec.ts:65:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e3]:
    - link "Skip to content" [ref=e4] [cursor=pointer]:
      - /url: "#main"
    - generic [ref=e5]:
      - banner [ref=e6]:
        - button "Open menu" [ref=e7] [cursor=pointer]
        - heading "Thesis" [level=1] [ref=e10]
        - button "Alerts unavailable in this preview" [disabled] [ref=e11]
      - main [ref=e14]:
        - region "Thesis tasks" [ref=e15]:
          - generic [ref=e16]:
            - heading "Thesis" [level=2] [ref=e17]
            - generic [ref=e18]: 334 tasks
            - generic [ref=e19]:
              - progressbar "Project completion" [ref=e20]
              - text: 20% complete
            - button "Rename project" [ref=e21] [cursor=pointer]
            - button "Delete project" [ref=e22] [cursor=pointer]
          - list "Thesis tasks" [ref=e23]:
            - listitem [ref=e24]:
              - checkbox "Complete Review the project draft and share all approved task updates" [ref=e25] [cursor=pointer]
              - generic [ref=e27]:
                - generic "Review the project draft and share all approved task updates" [ref=e28]
                - generic [ref=e29]:
                  - generic [ref=e30]: Thesis ·
                  - generic [ref=e31]: 2 days overdue
              - generic [ref=e32]: high priority
              - generic [ref=e35]: "Status: todo"
              - generic [ref=e36]:
                - button "Edit Review the project draft and share all approved task updates" [ref=e37] [cursor=pointer]: Edit
                - button "Delete Review the project draft and share all approved task updates" [ref=e38] [cursor=pointer]: Delete
            - listitem [ref=e39]:
              - checkbox "Complete Call Sam" [ref=e40] [cursor=pointer]
              - generic [ref=e42]:
                - generic "Call Sam" [ref=e43]
                - generic [ref=e44]:
                  - generic [ref=e45]: Thesis ·
                  - generic [ref=e46]: 2 days overdue
              - generic [ref=e47]: high priority
              - generic [ref=e50]: "Status: todo"
              - generic [ref=e51]:
                - button "Edit Call Sam" [ref=e52] [cursor=pointer]: Edit
                - button "Delete Call Sam" [ref=e53] [cursor=pointer]: Delete
            - listitem [ref=e54]:
              - checkbox "Complete Submit thesis documentation · 100" [ref=e55] [cursor=pointer]
              - generic [ref=e57]:
                - generic "Submit thesis documentation · 100" [ref=e58]
                - generic [ref=e59]:
                  - generic [ref=e60]: Thesis ·
                  - generic [ref=e61]: 2 days overdue
              - generic [ref=e62]: "Status: todo"
              - generic [ref=e63]:
                - button "Edit Submit thesis documentation · 100" [ref=e64] [cursor=pointer]: Edit
                - button "Delete Submit thesis documentation · 100" [ref=e65] [cursor=pointer]: Delete
            - listitem [ref=e66]:
              - checkbox "Complete Review Chapter 4 draft · 103" [ref=e67] [cursor=pointer]
              - generic [ref=e69]:
                - generic "Review Chapter 4 draft · 103" [ref=e70]
                - generic [ref=e71]:
                  - generic [ref=e72]: Thesis ·
                  - generic [ref=e73]: Sun, Nov 1
              - generic [ref=e74]: low priority
              - generic [ref=e77]: "Status: todo"
              - generic [ref=e78]:
                - button "Edit Review Chapter 4 draft · 103" [ref=e79] [cursor=pointer]: Edit
                - button "Delete Review Chapter 4 draft · 103" [ref=e80] [cursor=pointer]: Delete
            - listitem [ref=e81]:
              - checkbox "Complete Prepare defense slides · 106" [ref=e82] [cursor=pointer]
              - generic [ref=e84]:
                - generic "Prepare defense slides · 106" [ref=e85]
                - generic [ref=e86]:
                  - generic [ref=e87]: Thesis ·
                  - generic [ref=e88]: Wed, Nov 4
              - generic [ref=e89]: medium priority
              - generic [ref=e92]: "Status: todo"
              - generic [ref=e93]:
                - button "Edit Prepare defense slides · 106" [ref=e94] [cursor=pointer]: Edit
                - button "Delete Prepare defense slides · 106" [ref=e95] [cursor=pointer]: Delete
            - listitem [ref=e96]:
              - checkbox "Complete Review Chapter 4 draft · 112" [ref=e97] [cursor=pointer]
              - generic [ref=e99]:
                - generic "Review Chapter 4 draft · 112" [ref=e100]
                - generic [ref=e101]:
                  - generic [ref=e102]: Thesis ·
                  - generic [ref=e103]: Sun, Nov 1
              - generic [ref=e104]: "Status: in progress"
              - generic [ref=e105]:
                - button "Edit Review Chapter 4 draft · 112" [ref=e106] [cursor=pointer]: Edit
                - button "Delete Review Chapter 4 draft · 112" [ref=e107] [cursor=pointer]: Delete
            - listitem [ref=e108]:
              - checkbox "Complete Prepare defense slides · 115" [ref=e109] [cursor=pointer]
              - generic [ref=e111]:
                - generic "Prepare defense slides · 115" [ref=e112]
                - generic [ref=e113]:
                  - generic [ref=e114]: Thesis ·
                  - generic [ref=e115]: Wed, Nov 4
              - generic [ref=e116]: low priority
              - generic [ref=e119]: "Status: todo"
              - generic [ref=e120]:
                - button "Edit Prepare defense slides · 115" [ref=e121] [cursor=pointer]: Edit
                - button "Delete Prepare defense slides · 115" [ref=e122] [cursor=pointer]: Delete
            - listitem [ref=e123]:
              - checkbox "Complete Submit thesis documentation · 118" [ref=e124] [cursor=pointer]
              - generic [ref=e126]:
                - generic "Submit thesis documentation · 118" [ref=e127]
                - generic [ref=e128]:
                  - generic [ref=e129]: Thesis ·
                  - generic [ref=e130]: 2 days overdue
              - generic [ref=e131]: medium priority
              - generic [ref=e134]: "Status: todo"
              - generic [ref=e135]:
                - button "Edit Submit thesis documentation · 118" [ref=e136] [cursor=pointer]: Edit
                - button "Delete Submit thesis documentation · 118" [ref=e137] [cursor=pointer]: Delete
            - listitem [ref=e138]:
              - checkbox "Complete Review Chapter 4 draft · 121" [ref=e139] [cursor=pointer]
              - generic [ref=e141]:
                - generic "Review Chapter 4 draft · 121" [ref=e142]
                - generic [ref=e143]:
                  - generic [ref=e144]: Thesis ·
                  - generic [ref=e145]: Sun, Nov 1
              - generic [ref=e146]: high priority
              - generic [ref=e149]: "Status: todo"
              - generic [ref=e150]:
                - button "Edit Review Chapter 4 draft · 121" [ref=e151] [cursor=pointer]: Edit
                - button "Delete Review Chapter 4 draft · 121" [ref=e152] [cursor=pointer]: Delete
            - listitem [ref=e153]:
              - checkbox "Complete Submit thesis documentation · 127" [ref=e154] [cursor=pointer]
              - generic [ref=e156]:
                - generic "Submit thesis documentation · 127" [ref=e157]
                - generic [ref=e158]:
                  - generic [ref=e159]: Thesis ·
                  - generic [ref=e160]: 2 days overdue
              - generic [ref=e161]: low priority
              - generic [ref=e164]: "Status: in progress"
              - generic [ref=e165]:
                - button "Edit Submit thesis documentation · 127" [ref=e166] [cursor=pointer]: Edit
                - button "Delete Submit thesis documentation · 127" [ref=e167] [cursor=pointer]: Delete
            - listitem [ref=e168]:
              - checkbox "Complete Review Chapter 4 draft · 13" [ref=e169] [cursor=pointer]
              - generic [ref=e171]:
                - generic "Review Chapter 4 draft · 13" [ref=e172]
                - generic [ref=e173]:
                  - generic [ref=e174]: Thesis ·
                  - generic [ref=e175]: No due date
              - generic [ref=e176]: high priority
              - generic [ref=e179]: "Status: todo"
              - generic [ref=e180]:
                - button "Edit Review Chapter 4 draft · 13" [ref=e181] [cursor=pointer]: Edit
                - button "Delete Review Chapter 4 draft · 13" [ref=e182] [cursor=pointer]: Delete
          - button "Add a task to Thesis" [ref=e183] [cursor=pointer]
    - button "Quick Add" [ref=e184] [cursor=pointer]
    - navigation "Phone navigation" [ref=e187]:
      - link "Dashboard" [ref=e188] [cursor=pointer]:
        - /url: /
      - link "Tasks" [ref=e191] [cursor=pointer]:
        - /url: /tasks
      - button "Projects" [ref=e194] [cursor=pointer]
  - iframe [aria-hidden] [ref=e197]
```

# Test source

```ts
  25  |     })
  26  |     const parts = { title: bounds(title), project: bounds(meta[0]), due: bounds(meta[1]),
  27  |       priority: bounds(element.querySelector('[data-priority]')!),
  28  |       checkbox: bounds(element.querySelector('[data-row-action=complete]')!),
  29  |       edit: bounds(element.querySelector('[data-row-action=edit]')!),
  30  |       delete: bounds(element.querySelector('[data-row-action=delete]')!) }
  31  |     const entries = Object.entries(parts)
  32  |     const overlaps = entries.flatMap(([a, x], index) => entries.slice(index + 1).flatMap(([b, y]) =>
  33  |       Math.min(x.right, y.right) - Math.max(x.left, y.left) > .5
  34  |       && Math.min(x.bottom, y.bottom) - Math.max(x.top, y.top) > .5 ? [`${a}/${b}`] : []))
  35  |     const rect = bounds(element)
  36  |     return { rect, parts, overlaps, title: { scrollHeight: title.scrollHeight, clientHeight: title.clientHeight,
  37  |       lineHeight: parseFloat(getComputedStyle(title).lineHeight) },
  38  |       insideRow: entries.every(([, r]) => r.top >= rect.top && r.bottom <= rect.bottom
  39  |         && r.left >= rect.left && r.right <= rect.right),
  40  |       noHorizontalScroll: element.scrollWidth <= element.clientWidth,
  41  |       minHeight: parseFloat(getComputedStyle(element).minHeight), heightStyle: element.style.height }
  42  |   })
  43  | }
  44  | 
  45  | function expectClear(result: Awaited<ReturnType<typeof geometry>>) {
  46  |   expect(result.title.scrollHeight).toBeLessThanOrEqual(result.title.clientHeight)
  47  |   expect(result.overlaps).toEqual([])
  48  |   expect(result.insideRow).toBe(true)
  49  |   expect(result.noHorizontalScroll).toBe(true)
  50  |   for (const action of [result.parts.checkbox, result.parts.edit, result.parts.delete]) {
  51  |     expect(action.width).toBeGreaterThanOrEqual(44)
  52  |     expect(action.height).toBeGreaterThanOrEqual(44)
  53  |   }
  54  | }
  55  | 
  56  | async function adjacentRows(list: Locator) {
  57  |   return list.locator('[data-task-id]').evaluateAll((elements) => {
  58  |     const rects = elements.map((element) => element.getBoundingClientRect()).sort((a, b) => a.top - b.top)
  59  |     return rects.every((rect, index) => index === 0 || rect.top >= rects[index - 1].bottom - .5)
  60  |   })
  61  | }
  62  | 
  63  | for (const width of [320, 360, 390, 1280]) for (const taskCount of [6, 1000]) {
  64  |   const mode = taskCount === 6 ? 'plain' : 'virtual'
  65  |   test(`G3 ${mode} Project rows fit long and short titles at ${width}px`, async ({ page }, info) => {
  66  |     await page.setViewportSize({ width, height: width === 1280 ? 900 : 800 })
  67  |     const diagnostics = collectDiagnostics(page)
  68  |     const measurementWarnings: string[] = []
  69  |     page.on('console', (message) => {
  70  |       if (message.type() === 'warning' && message.text().includes('Missing attribute name'))
  71  |         measurementWarnings.push(message.text())
  72  |     })
  73  |     const uid = await signIn(page, '/', { seed: false })
  74  |     const seed = await seedUser(uid, { taskCount })
  75  |     const projectTasks = seed.tasks.filter((task) => task.projectId === 'project-1')
  76  |       .sort((a, b) => a.id.localeCompare(b.id))
  77  |     const [longTask, shortTask] = projectTasks
  78  |     await externalWrite(uid, async (database, root) => {
  79  |       const batch = database.batch()
  80  |       for (const [task, title] of [[longTask, longTitle], [shortTask, 'Call Sam']] as const)
  81  |         batch.update(database.doc(`${root}/tasks/${task.id}`), { title, priority: 'high', status: 'todo', completedAt: null })
  82  |       await batch.commit()
  83  |     })
  84  |     await waitForSync(page, { tasks: taskCount })
  85  |     await navigate(page, '/projects/project-1')
  86  |     const list = page.getByRole('list', { name: 'Thesis tasks', exact: true })
  87  |     await expect(list).toHaveAttribute('data-virtualized', String(mode === 'virtual'))
  88  |     const longRow = list.locator(`[data-task-id="${longTask.id}"]`)
  89  |     const shortRow = list.locator(`[data-task-id="${shortTask.id}"]`)
  90  |     await expect(longRow.locator('[title]')).toHaveText(longTitle)
  91  |     await expect(shortRow.locator('[title]')).toHaveText('Call Sam')
  92  |     await page.evaluate(() => document.fonts.ready)
  93  |     const initial = { long: await geometry(longRow), short: await geometry(shortRow),
  94  |       adjacent: await adjacentRows(list), noHorizontalScroll: await page.evaluate(() =>
  95  |         document.documentElement.scrollWidth <= innerWidth),
  96  |       listFits: await list.evaluate((element) => element.scrollWidth <= element.clientWidth) }
  97  |     observations.set(info.testId, { name: `project-rows-${mode}-${width}`, result: { initial } })
  98  |     await capture(page, `g3-project-rows-${mode}`)
  99  |     expectClear(initial.long)
  100 |     expectClear(initial.short)
  101 |     expect(initial.adjacent && initial.noHorizontalScroll && initial.listFits).toBe(true)
  102 |     if (width < 1280) {
  103 |       for (const result of [initial.long, initial.short]) {
  104 |         const lowerBandTop = Math.min(result.parts.project.top, result.parts.due.top,
  105 |           result.parts.priority.top, result.parts.edit.top, result.parts.delete.top)
  106 |         expect(Math.max(result.parts.title.bottom, result.parts.checkbox.bottom)).toBeLessThanOrEqual(lowerBandTop)
  107 |         expect(result.parts.delete.right).toBeCloseTo(result.rect.right - 12, 0)
  108 |         const bandCenter = (result.parts.edit.top + result.parts.edit.bottom) / 2
  109 |         for (const part of [result.parts.project, result.parts.due, result.parts.priority, result.parts.delete])
  110 |           expect((part.top + part.bottom) / 2).toBeCloseTo(bandCenter, 0)
  111 |       }
  112 |       expect(initial.long.parts.title.height).toBeGreaterThan(initial.long.title.lineHeight)
  113 |       // A measured phone list must return to the existing fixed desktop geometry.
  114 |       await page.setViewportSize({ width: 1280, height: 900 })
  115 |       const desktopHeight = await page.evaluate(() =>
  116 |         parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--row-height')))
  117 |       await expect.poll(async () => (await geometry(longRow)).rect.height).toBe(desktopHeight)
  118 |       await expect.poll(() => adjacentRows(list)).toBe(true)
  119 |       const desktop = { long: await geometry(longRow), short: await geometry(shortRow) }
  120 |       expectClear(desktop.long)
  121 |       expectClear(desktop.short)
  122 |       await page.setViewportSize({ width, height: 800 })
  123 |       await expect.poll(async () => (await geometry(longRow)).parts.title.height)
  124 |         .toBeGreaterThan(initial.long.title.lineHeight)
> 125 |       await expect.poll(() => adjacentRows(list)).toBe(true)
      |                                                   ^ Error: expect(received).toBe(expected) // Object.is equality
  126 |       expectClear(await geometry(longRow))
  127 |       // Variable titles must remeasure while mounted, not only on initial rendering.
  128 |       const expanded = `${longTitle} ${'More project details '.repeat(8)}`
  129 |       await longRow.getByRole('button', { name: `Edit ${longTitle}`, exact: true }).click()
  130 |       const dialog = page.getByRole('dialog')
  131 |       await dialog.getByLabel('Title').fill(expanded)
  132 |       await dialog.getByRole('button', { name: 'Save changes' }).click()
  133 |       await expect(longRow.locator('[title]')).toHaveText(expanded)
  134 |       await expect.poll(async () => (await geometry(longRow)).rect.height).toBeGreaterThan(initial.long.rect.height)
  135 |       await expect.poll(() => adjacentRows(list)).toBe(true)
  136 |       const grown = await geometry(longRow)
  137 |       expectClear(grown)
  138 |       observations.set(info.testId, { name: `project-rows-${mode}-${width}`, result: { initial, desktop, grown } })
  139 |       await capture(page, `g3-project-rows-${mode}-grown`)
  140 |     } else {
  141 |       const expectedHeight = await page.evaluate(() =>
  142 |         parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--row-height')))
  143 |       expect(initial.long.rect.height).toBe(expectedHeight)
  144 |       expect(initial.short.rect.height).toBe(expectedHeight)
  145 |     }
  146 |     await longRow.focus()
  147 |     await page.keyboard.press('End')
  148 |     await expect(list.locator(`[aria-posinset="${projectTasks.length}"]`)).toBeFocused()
  149 |     await page.keyboard.press('Home')
  150 |     await expect(longRow).toBeFocused()
  151 |     await expect.poll(() => adjacentRows(list)).toBe(true)
  152 |     expect(measurementWarnings).toEqual([])
  153 |     expectNormalDiagnostics(diagnostics)
  154 |     expect((await writeSnapshot(page)).projects).toHaveLength(4)
  155 |   })
  156 | }
  157 | 
```