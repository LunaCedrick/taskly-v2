# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: g3-reveal-once.spec.ts >> G3 reveal is consumed after Quick Add: 150 tasks at 1280px
- Location: tests\e2e\g3-reveal-once.spec.ts:19:3

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  getByRole('list', { name: 'Thesis tasks', exact: true }).locator('[data-row-action="complete"]').first()
Expected: "true"
Received: "false"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" getByRole('list', { name: 'Thesis tasks', exact: true }).locator('[data-row-action="complete"]').first() with timeout 5000ms
  - waiting for getByRole('list', { name: 'Thesis tasks', exact: true }).locator('[data-row-action="complete"]').first()
    14 × locator resolved to <button role="checkbox" aria-checked="false" data-row-action="complete" class="_checkTarget_38fq1_33" aria-label="Complete Submit thesis documentation · 10">…</button>
       - unexpected value "false"

```

```yaml
- checkbox "Complete Submit thesis documentation · 10"
```

# Test source

```ts
  1  | import { test, expect, type Locator, type Page } from '@playwright/test'
  2  | import { signIn } from './fixtures/auth'
  3  | import { seedUser } from './fixtures/firestore'
  4  | import { capture, collectDiagnostics, expectNormalDiagnostics, navigate, waitForSync } from './fixtures/sync'
  5  | import { saveExperiment, writeSnapshot } from './fixtures/writes'
  6  | 
  7  | const frames = (page: Page) => page.evaluate(() => new Promise<void>((resolve) =>
  8  |   requestAnimationFrame(() => requestAnimationFrame(() => resolve()))))
  9  | 
  10 | async function confirmed(page: Page, id: string) {
  11 |   await page.evaluate((id) => window.__TASKLY_G3_WRITES_TEST__!.wait(id), id)
  12 |   await expect.poll(async () => (await writeSnapshot(page)).waiters[id]?.status).toBe('acknowledged')
  13 |   await frames(page)
  14 | }
  15 | 
  16 | const scrollTop = (list: Locator) => list.evaluate((element) => element.scrollTop)
  17 | 
  18 | for (const width of [390, 1280]) for (const taskCount of [150, 1000]) {
  19 |   test(`G3 reveal is consumed after Quick Add: ${taskCount} tasks at ${width}px`, async ({ page }, info) => {
  20 |     await page.setViewportSize({ width, height: width === 390 ? 844 : 900 })
  21 |     const diagnostics = collectDiagnostics(page)
  22 |     const uid = await signIn(page, '/', { seed: false })
  23 |     await seedUser(uid, { taskCount })
  24 |     await waitForSync(page, { tasks: taskCount })
  25 |     await navigate(page, '/projects/project-1')
  26 |     const list = page.getByRole('list', { name: 'Thesis tasks', exact: true })
  27 |     await expect(list).toHaveAttribute('data-virtualized', String(taskCount === 1000))
  28 |     const title = `Reveal once ${taskCount} ${width}`
  29 |     await page.getByRole('button', { name: 'Quick Add', exact: true }).click()
  30 |     const input = page.getByRole('dialog').getByLabel('Title')
  31 |     await input.fill(title)
  32 |     await input.press('Enter')
  33 |     await expect(input).toHaveValue('')
  34 |     await confirmed(page, 'after-add')
  35 |     const added = (await writeSnapshot(page)).tasks.find((task) => task.title === title)!
  36 |     const addedRow = list.locator(`[data-task-id="${added.id}"]`)
  37 |     await expect(addedRow).toBeInViewport()
  38 |     const revealedTop = await scrollTop(list)
  39 |     expect(revealedTop).toBeGreaterThan(0)
  40 |     await page.keyboard.press('Escape')
  41 |     await list.evaluate((element) => { element.scrollTop = 0 })
  42 |     await frames(page)
  43 |     await list.evaluate((element) => {
  44 |       element.dataset.maxObservedScroll = '0'
  45 |       element.addEventListener('scroll', () => {
  46 |         element.dataset.maxObservedScroll = String(Math.max(Number(element.dataset.maxObservedScroll), element.scrollTop))
  47 |       })
  48 |     })
  49 |     const above = list.locator('[data-row-action="complete"]').first()
  50 |     await above.click()
> 51 |     await expect(above).toHaveAttribute('aria-checked', 'true')
     |                         ^ Error: expect(locator).toHaveAttribute(expected) failed
  52 |     await confirmed(page, 'after-complete')
  53 |     const afterComplete = await scrollTop(list)
  54 |     const maximumAfterComplete = Number(await list.getAttribute('data-max-observed-scroll'))
  55 |     expect(afterComplete).toBe(0)
  56 |     expect(maximumAfterComplete).toBe(0)
  57 |     if (taskCount === 1000) await expect(addedRow).toHaveCount(0)
  58 |     await navigate(page, '/')
  59 |     await navigate(page, '/projects/project-1')
  60 |     await frames(page)
  61 |     const afterReturn = await scrollTop(list)
  62 |     expect(afterReturn).toBe(0)
  63 |     if (taskCount === 1000) await expect(addedRow).toHaveCount(0)
  64 |     await navigate(page, '/tasks')
  65 |     const all = page.getByRole('list', { name: 'All tasks', exact: true })
  66 |     await frames(page)
  67 |     const myTasks = await scrollTop(all)
  68 |     expect(myTasks).toBe(0)
  69 |     if (taskCount === 1000) await expect(all.locator(`[data-task-id="${added.id}"]`)).toHaveCount(0)
  70 |     await capture(page, `g3-reveal-once-${taskCount}`)
  71 |     await saveExperiment(info, `reveal-once-${taskCount}-${width}`, {
  72 |       revealedTop, afterComplete, maximumAfterComplete, afterReturn, myTasks,
  73 |     })
  74 |     expectNormalDiagnostics(diagnostics)
  75 |   })
  76 | }
  77 | 
```